# Calculadora Básica en Python + Flask

Proyecto simple de una calculadora web.
